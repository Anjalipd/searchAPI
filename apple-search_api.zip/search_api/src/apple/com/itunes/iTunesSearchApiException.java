package apple.com.itunes;
public class iTunesSearchApiException extends RuntimeException {
    public iTunesSearchApiException(String message) {
        super(message);
    }
}