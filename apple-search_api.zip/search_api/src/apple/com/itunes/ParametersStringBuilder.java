package apple.com.itunes;

import apple.com.itunes.parameter.LookUpParameters;
import apple.com.itunes.parameter.SearchParameters;
import apple.com.itunes.parameter.parameters.Term;

import java.util.List;


class ParametersStringBuilder {
    public static String buildLookUpStringParams(LookUpParameters params) {
        throw new UnsupportedOperationException("The lookup method is not yet implemented.");
    }

    public static String buildSearchStringParams(SearchParameters params) {
        StringBuilder resultQuery = new StringBuilder();
        buildTerms(params.getTerms(), resultQuery);
        resultQuery.append(params.getCountry().createSearchParameter()).append("&");
        resultQuery.append(params.getMedia().createSearchParameter()).append("&");
      
        if (params.getEntity() != null) {
            resultQuery.append(params.getEntity().createSearchParameter()).append("&");
        }
        if (params.getAttribute() != null) {
            resultQuery.append(params.getAttribute().createSearchParameter()).append("&");
        }

        resultQuery.append(params.getLimit().createSearchParameter()).append("&");
        return resultQuery.toString();
    }

    private static void buildTerms(List<String> terms, StringBuilder resultQuery) {
        if (terms != null) {
            resultQuery.append(new Term(terms).createSearchParameter()).append("&");
        } else {
            throw new iTunesSearchApiException("Terms are mandatory field to search for search, please specify and try again.");
        }
    }
}

