package apple.com.itunes.parameter;

public class LookUpParameters implements Parameters {
}
