package apple.com.itunes.parameter;

public interface Parameters {

}
