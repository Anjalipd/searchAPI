package apple.com.itunes.parameter.parameters.attributes.entities;
import apple.com.itunes.parameter.parameters.Parameter;

public interface Entity extends Parameter {
}
