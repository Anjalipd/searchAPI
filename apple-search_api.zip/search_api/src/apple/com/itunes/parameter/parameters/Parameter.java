package apple.com.itunes.parameter.parameters;

public interface Parameter {
    String createSearchParameter();
}