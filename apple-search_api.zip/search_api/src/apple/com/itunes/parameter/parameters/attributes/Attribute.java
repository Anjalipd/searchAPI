package apple.com.itunes.parameter.parameters.attributes;
import apple.com.itunes.parameter.parameters.Parameter;

public interface Attribute extends Parameter {
}
